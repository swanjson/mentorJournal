// FILES FOR 4x4 (there are 15) 0:15
tileNames_4x4 = [];
for(var i=0; i<15; i++){
    tileNames_4x4.push("Tile128-"+i+".png");
    console.log("Tile128-"+i+".png");
}
// FILES FOR 8x8 (there are 63) 0:62
tileNames_8x8 = [];
for(var i=0; i<63; i++){
    tileNames_8x8.push("Tile64-"+i+".png");
    console.log("Tile64-"+i+".png");
}

function shuffle(array) {
    array.sort(() => Math.random() - 0.5);
}
  
shuffle(tileNames_4x4);
console.log(tileNames_4x4);